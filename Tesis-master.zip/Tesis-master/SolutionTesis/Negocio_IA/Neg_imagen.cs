﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Datos_IA;
using Entidad_IA;
namespace Negocio_IA
{
    public class Neg_imagen
    {
        public void ingresar_imagen(imagen objimagen)
        {
            Datimagen objden = new Datimagen();
            objden.ingresar_imagen(objimagen);
        }
    }
}
