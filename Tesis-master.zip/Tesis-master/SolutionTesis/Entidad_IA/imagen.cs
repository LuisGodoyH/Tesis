﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidad_IA
{
    public class imagen
    {
     public int Id_Imagen { get; set; }
     public string Ruta { get; set; }
     public string Nombre { get; set; }
    }
}
